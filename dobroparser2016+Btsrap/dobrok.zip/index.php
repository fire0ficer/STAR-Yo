<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>программммммка 228</title>
        <meta name="viewport" content="width=device-width, initial-scale=0.9">
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/themify-icons.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/flexslider.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/lightbox.min.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/ytplayer.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/theme.css" rel="stylesheet" type="text/css" media="all" />
        <link href="css/custom.css" rel="stylesheet" type="text/css" media="all" />

       
        <link href='http://fonts.googleapis.com/css?family=Lato:300,400%7CRaleway:100,400,300,500,600,700%7COpen+Sans:400,500,600' rel='stylesheet' type='text/css'>
    </head>
    <body>

        
        <div class="main-container">
            <section class="page-title page-title-4 bg-secondary">
                <div align="center">
                   <img alt="бздуканы" reap class="background-image" title ="ololo" src="alah.jpg" height="250" repeat-x />
                   <img alt="бздуканы" reap class="background-image" title ="ololo" src="alah.jpg" height="250" repeat-x />
                   <img alt="бздуканы" reap class="background-image" title ="ololo" src="alah.jpg" height="250" repeat-x />
                   <img alt="бздуканы" reap class="background-image" title ="ololo" src="alah.jpg" height="250" repeat-x />  
                   <img alt="бздуканы" reap class="background-image" title ="ololo" src="alah.jpg" height="250" repeat-x />
                   </div>              
            </section>
            <section>
                <div class="container">
                    <div class="row">
                    <form  action="testik.php"  method="post">
                        <div class="col-sm-6">
                            <h4 class="uppercase mb16">Сюда текст вставляй</h4>
                            <p class="lead mb64">
                                Вроде сюда можно книжку целую впихнуть, но если вдруг много впихнул и ошибка, то обязательно сообщи мне
                           
                            
                            <textarea name="text" placeholder="Cюда делай ctrl+v" rows="10"></textarea>
                            
                        </div>
                        <div class="col-sm-6">
                            <h4 class="uppercase mb16">Тут выбирай с чем сравнивать номер</h4>
                            <p class="lead mb64">
                                Сравнивать можно с риелтором и +1 таблицой из аренды или продажии
                            </p>
                            
                                 <span>  С номерами риелторов сравнивать?  </span>
                                <div class="checkbox-option pull-right">
                                    <div class="inner"></div>
                                    <input type="checkbox" name="rielt" value="1" />
                                </div>
                           
                            
                            
                               <hr> <h5 class="uppercase">Выбирай таблицу для сравнения</h5>
                                
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio"  name="radio" value="ar1k" />
                                    </div>
                                    <span>Аренда 1к</span>                                
                                
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="ar2k" />
                                    </div>
                                    <span>Аренда 2к</span>                               
                                
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="ar3k" />
                                    </div>
                                    <span>Аренда 3к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="ar4k" />
                                    </div>
                                    <span>Аренда 4к</span>
                                    <br>
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="ar5k" />
                                    </div>
                                    <span>Аренда 5к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="ardom" />
                                    </div>
                                    <span>Аренда дом</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="arkom" />
                                    </div>
                                    <span>Аренда комната</span>
                                    <br>
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="arproch" />
                                    </div>
                                    <span>Аренда прочее</span><hr>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pr1k" />
                                    </div>
                                    <span>Продажа 1к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pr2k" />
                                    </div>
                                    <span>Продажа 2к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pr3k" />
                                    </div>
                                    <span>Продажа 3к</span>
                                     <br>   
                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pr4k" />
                                    </div>
                                    <span>Продажа 4к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pr5k" />
                                    </div>
                                    <span>Продажа 5к</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="prdom" />
                                    </div>
                                    <span>Продажа дом</span>
                                    <br> 

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="pruch" />
                                    </div>
                                    <span>Продажа участок</span>

                                    <div class="radio-option">
                                        <div class="inner"></div>
                                        <input type="radio" name="radio" value="proff" />
                                    </div>
                                    <span>Продажа офис</span>
                                    
                                                                    
                           


                            <input type="submit" value="Сравнить обявления с номерами" />
                             </form>
                        </div>
                    </div>
                    <div class="row">
                   <form  action="index3.php"  method="post">
                     <h5 class="uppercase" align="center">Выбери таблицу для отображения</h5>
                     <div class="select-option">

                                <i class="ti-angle-down"></i>
                                <select name="type">
                                    <option value="ar1k" selected>Аренда 1к</option>
                                    <option value="ar2k">Аренда 2к</option>
                                    <option value="ar3k">Аренда 3к</option>
                                    <option value="ar4k">Аренда 4к</option>
                                    <option value="ar5k">Аренда 54</option>
                                    <option value="ardom">Аренда дом</option>
                                    <option value="arkom">Аренда комната</option>
                                    <option value="arproch">Аренда прочее</option>
                                    <option value="pr1k">Продажа 1к</option>
                                    <option value="pr2k">Продажа 2к</option>
                                    <option value="pr3k">Продажа 3к</option>
                                    <option value="pr4k">Продажа 4к</option>
                                    <option value="pr5k">Продажа 5к</option>
                                    <option value="prdom">Продажа дом</option>
                                    <option value="pruch">Продажа участок</option>
                                    <option value="proff">Продажа офис</option>
                                    <option value="rielt">Риелторы</option>
                                                                    </select>
                            </div>
                            <input type="submit" value="Показать номера выбранной категории" />
                    </form>   
                    </div>

                    <!--end of row-->
                </div>
                <!--end of container-->
            </section>
            
        </div>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/flickr.js"></script>
        <script src="js/flexslider.min.js"></script>
        <script src="js/lightbox.min.js"></script>
        <script src="js/masonry.min.js"></script>
        <script src="js/twitterfetcher.min.js"></script>
        <script src="js/spectragram.min.js"></script>
        <script src="js/ytplayer.min.js"></script>
        <script src="js/countdown.min.js"></script>
        <script src="js/smooth-scroll.min.js"></script>
        <script src="js/parallax.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>